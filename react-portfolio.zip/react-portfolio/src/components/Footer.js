import React from "react"

function Footer(){

return(
<footer id="sticky-footer" className="py-4 bColor text-white-50">
    <div className="container text-center">
          <small>Copyright &copy;</small>
    </div>
</footer>
)
}

export default Footer;